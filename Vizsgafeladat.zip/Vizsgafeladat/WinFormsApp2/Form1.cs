using LogCommon;
using System.Data;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        private SQL dbContext;
        private DataTable dataTable;
        private DataView dataView;

        public Form1()
        {
            InitializeComponent();
            PopulateDataGridView();

            button2.Enabled = false;
        }

        private void PopulateDataGridView()
        {
            dataTable = new DataTable();
            dataTable.Columns.Add("Id", typeof(int));
            dataTable.Columns.Add("CorrelationId", typeof(string));
            dataTable.Columns.Add("DateUtc", typeof(DateTime));
            dataTable.Columns.Add("Thread", typeof(int));
            dataTable.Columns.Add("Level", typeof(string));
            dataTable.Columns.Add("Logger", typeof(string));
            dataTable.Columns.Add("Message", typeof(string));
            dataTable.Columns.Add("Exception", typeof(string));

            int errorCount = 0;
            int debugCount = 0;
            using (SQL sql = new SQL())
            {
                foreach (var entry in sql.logEntries)
                {
                    dataTable.Rows.Add(entry.Id, entry.CorrelationId, entry.DateUtc, entry.Thread, entry.level, entry.Logger, entry.Message, entry.Exception);
                    if (entry.level.ToLower() == "error")
                        errorCount++;
                    else if (entry.level.ToLower() == "debug")
                        debugCount++;
                }
            }

            dataView = dataTable.DefaultView;
            dataGridView1.DataSource = dataView;
            label10.Text = $"{dataGridView1.RowCount}";
            label11.Text = $"{debugCount}";
            label12.Text = $"{errorCount}";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}