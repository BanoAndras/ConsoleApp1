﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.Models
{
    [Table("logentries")]
    public class LogEntry
    {
        [Key]
        [Required]
        public int Id { get; set; }
        public string CorrelationId { get; set; }
        public DateTime DateUtc { get; set; }
        public int Thread {  get; set; }

        public string level { get; set; }

        public string Logger { get; set; }

        public string Message { get; set; }

        public string Exception { get; set; }





    }
}
