﻿using Microsoft.AspNetCore.Mvc;

using LogCommon;
using ClassLibrary2.Models;

namespace LogAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LogController : ControllerBase
    {

        [HttpGet(Name = "GetAllLogEntries")]
        public IActionResult Get()
        {
            try
            {
                using (SQL sql = new SQL())
                {
                    return Ok(sql.logEntries.ToList().Take(20));
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Hiba!");
            }
        }

        [HttpGet("GetLogEntry")]
        public IActionResult GetLogById([FromHeader] string id)
        {
            try
            {
                using (SQL sql = new SQL())
                {
                    return Ok(sql.logEntries.Single(x => x.Id == int.Parse(id)));
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("SearchLogEntry")]
        public IActionResult SearchLogEntry([FromBody] string text)
        {
            try
            {
                List<LogEntry> entries = new List<LogEntry>();

                using (SQL sql = new SQL())
                {
                    sql.logEntries.ToList().ForEach(x =>
                    {
                        if (x.Message.Contains(text) || x.Exception.Contains(text) || $"{x.DateUtc}".Contains(text))
                        {
                            entries.Add(x);
                        }
                    });
                    sql.SaveChanges();
                }

                return Ok(entries);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("InsertLogEntry")]
        public IActionResult InsertLogEntry([FromBody] LogEntry entry)
        {
            try
            {
                using (SQL sql = new SQL())
                {
                    sql.logEntries.Add(entry);
                    sql.SaveChanges();
                }

                return Ok(entry);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}